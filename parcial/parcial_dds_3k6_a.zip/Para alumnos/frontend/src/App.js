import './App.css';
import Presupuestos from './components/Presupuestos';

function App() {
  return (
    <div>
      <Presupuestos />
    </div>
  );
}

export default App;
