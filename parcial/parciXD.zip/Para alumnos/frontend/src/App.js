import './App.css';
import Pedidos from './components/Pedidos';

function App() {
  return (
    <div>
      <Pedidos />
    </div>
  );
}

export default App;
