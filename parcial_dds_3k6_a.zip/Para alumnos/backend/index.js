import express from 'express'
import cors from 'cors'

console.log('Completar...')
