import express from 'express'
import { Pedidos } from '../models/pedidos.js';
import { Sequelize } from 'sequelize';

console.log('Completar...')
