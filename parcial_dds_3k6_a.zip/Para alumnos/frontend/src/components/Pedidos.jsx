import React, {  useState } from 'react';
import { useForm } from 'react-hook-form';
import axios from 'axios';
import ListadoPedidos from './ListadoPedidos';

const Pedidos = () => {
  return (
    <div className="container">
      <h3>Formulario de Búsqueda</h3>
      <div className="card mb-3">
        <div className="card-body">
           {/*completar*/}
        </div>
      </div>
      {lista && <ListadoPedidos lista={lista} />}
    </div>
  );
};

export default Pedidos;
