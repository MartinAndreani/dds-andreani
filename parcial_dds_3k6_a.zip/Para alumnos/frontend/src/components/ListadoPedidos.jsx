import React from 'react';

const ListadoPedidos = ({ lista }) => {
  
  return (
    <div className="container mt-3">
      <h4>Pedidos</h4>
      <table className="table table-striped">
         {/*completar*/}
      </table>
    </div>
  );
};

export default ListadoPedidos;
