import './App.css';
import Players from './components/Players';

function App() {
  return (
    <div>
      <Players />
    </div>
  );
}

export default App;
